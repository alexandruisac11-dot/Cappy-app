package com.example.companion

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.CallLog
import android.provider.CallLog.Calls
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.Telephony
import android.telecom.TelecomManager
import android.telephony.SmsManager
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Everything Capri can DO on the Phone. Claude picks these via tool use. */
object Tools {

    private class P(val name: String, val type: String, val desc: String, val req: Boolean = true)

    private fun tool(name: String, desc: String, vararg ps: P): JSONObject {
        val props = JSONObject()
        val req = JSONArray()
        ps.forEach {
            props.put(it.name, JSONObject().put("type", it.type).put("description", it.desc))
            if (it.req) req.put(it.name)
        }
        return JSONObject().put("name", name).put("description", desc)
            .put("input_schema", JSONObject().put("type", "object").put("properties", props).put("required", req))
    }

    private val CONFIRM = P("confirmed", "boolean",
        "true ONLY after you read the recipient and exact message back and the user said yes")

    val schema: JSONArray = JSONArray()
        .put(tool("call_contact", "Place a phone call to a saved contact or number. Only when the user asked to call.",
            P("name", "string", "Contact name as said, e.g. Mom, or a phone number")))
        .put(tool("answer_call", "Answer the phone call that is currently ringing."))
        .put(tool("end_call", "Hang up the current phone call."))
        .put(tool("read_call_log", "Read the user's recent calls (incoming, outgoing, missed).",
            P("count", "integer", "How many calls, default 5", false)))
        .put(tool("read_sms", "Read recent text messages (SMS), optionally only with one contact.",
            P("contact", "string", "Contact name or number; omit for all recent texts", false),
            P("count", "integer", "How many messages, default 5", false)))
        .put(tool("send_sms", "Send a text message (SMS). Always confirm with the user first.",
            P("to", "string", "Contact name or phone number"),
            P("text", "string", "The message to send"), CONFIRM))
        .put(tool("read_recent_messages", "Recent chat notifications from other apps (WhatsApp, Instagram, etc.)."))
        .put(tool("reply_to_message", "Reply to a recent chat notification (WhatsApp, Instagram, etc.). Always confirm first.",
            P("sender", "string", "Name of the person/chat as shown in the notification"),
            P("text", "string", "The reply to send"), CONFIRM))
        .put(tool("open_app", "Open an installed app by name, e.g. TikTok, Instagram, Camera.",
            P("name", "string", "App name")))
        .put(tool("remember", "Save a short fact about the user to long-term memory (names, preferences, plans).",
            P("note", "string", "The fact, one short sentence")))

    fun run(ctx: Context, name: String, input: JSONObject): String = when (name) {
        "call_contact" -> call(ctx, input.optString("name"))
        "answer_call" -> answer(ctx)
        "end_call" -> hangUp(ctx)
        "read_call_log" -> callLog(ctx, input.optInt("count", 5).coerceIn(1, 15))
        "read_sms" -> readSms(ctx, input.optString("contact"), input.optInt("count", 5).coerceIn(1, 15))
        "send_sms" -> sendSms(ctx, input.optString("to"), input.optString("text"), input.optBoolean("confirmed", false))
        "read_recent_messages" -> notifs()
        "reply_to_message" -> replyMsg(ctx, input.optString("sender"), input.optString("text"), input.optBoolean("confirmed", false))
        "open_app" -> openApp(ctx, input.optString("name"))
        "remember" -> { Brain.addNote(ctx, input.optString("note")); "Saved." }
        else -> "Unknown tool: $name"
    }

    // ---------- helpers ----------
    private fun need(ctx: Context, perm: String, what: String) {
        if (ctx.checkSelfPermission(perm) != PackageManager.PERMISSION_GRANTED)
            error("$what permission is missing. Tell the user to grant it from the Capri app (and 'Allow restricted settings' if Android blocks it).")
    }

    private val fmt get() = SimpleDateFormat("d MMM HH:mm", Locale.getDefault())

    private fun findContacts(ctx: Context, q: String): List<Pair<String, String>> {
        val seen = LinkedHashMap<String, String>() // number -> name
        ctx.contentResolver.query(
            Phone.CONTENT_URI,
            arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER),
            "${Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$q%"), null
        )?.use { c ->
            while (c.moveToNext()) {
                val n = c.getString(0) ?: continue
                val num = c.getString(1) ?: continue
                val key = num.filter { it.isDigit() || it == '+' }
                if (key.isNotEmpty() && key !in seen) seen[key] = n
            }
        }
        return seen.map { it.value to it.key }
    }

    /** Returns (display name, number) or throws a helpful message the model can act on. */
    private fun resolve(ctx: Context, q: String): Pair<String, String> {
        if (q.isBlank()) error("No name given.")
        if (q.count { it.isDigit() } >= 6) return q to q.filter { it.isDigit() || it == '+' }
        need(ctx, Manifest.permission.READ_CONTACTS, "Contacts")
        val hits = findContacts(ctx, q)
        if (hits.isEmpty()) error("No contact matching '$q'. Try a nickname or another spelling.")
        val exact = hits.filter { it.first.equals(q, ignoreCase = true) }
        val pool = if (exact.isNotEmpty()) exact else hits
        val names = pool.map { it.first }.distinct()
        if (names.size > 1) error("Several contacts match: ${names.joinToString()}. Ask the user which one.")
        return pool.first()
    }

    private fun nameFor(ctx: Context, number: String?): String {
        if (number.isNullOrBlank()) return "Unknown"
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return number
        val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
        ctx.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) return it.getString(0) ?: number
        }
        return number
    }

    // ---------- calls ----------
    private fun call(ctx: Context, q: String): String {
        need(ctx, Manifest.permission.CALL_PHONE, "Phone")
        val (contact, number) = resolve(ctx, q)
        ctx.startActivity(
            Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(number)))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        return "Calling $contact now."
    }

    @Suppress("DEPRECATION", "MissingPermission")
    private fun answer(ctx: Context): String {
        need(ctx, Manifest.permission.ANSWER_PHONE_CALLS, "Answer calls")
        ctx.getSystemService(TelecomManager::class.java).acceptRingingCall()
        return "Answered."
    }

    @Suppress("DEPRECATION", "MissingPermission")
    private fun hangUp(ctx: Context): String {
        need(ctx, Manifest.permission.ANSWER_PHONE_CALLS, "End calls")
        val ok = ctx.getSystemService(TelecomManager::class.java).endCall()
        return if (ok) "Call ended." else "There was no call to end."
    }

    private fun callLog(ctx: Context, count: Int): String {
        need(ctx, Manifest.permission.READ_CALL_LOG, "Call log")
        val out = mutableListOf<String>()
        ctx.contentResolver.query(
            Calls.CONTENT_URI,
            arrayOf(Calls.NUMBER, Calls.CACHED_NAME, Calls.TYPE, Calls.DATE, Calls.DURATION),
            null, null, "date DESC LIMIT $count"
        )?.use { c ->
            while (c.moveToNext()) {
                val num = c.getString(0)
                val who = c.getString(1) ?: nameFor(ctx, num)
                val type = when (c.getInt(2)) {
                    Calls.INCOMING_TYPE -> "incoming"
                    Calls.OUTGOING_TYPE -> "outgoing"
                    Calls.MISSED_TYPE -> "missed"
                    Calls.REJECTED_TYPE -> "rejected"
                    else -> "other"
                }
                out += "[${fmt.format(Date(c.getLong(3)))}] $type, $who, ${c.getInt(4)}s"
            }
        }
        return if (out.isEmpty()) "No calls in the log." else out.joinToString("\n")
    }

    // ---------- SMS ----------
    private fun readSms(ctx: Context, who: String, count: Int): String {
        need(ctx, Manifest.permission.READ_SMS, "SMS")
        val target = if (who.isNotBlank()) resolve(ctx, who) else null
        val tail = target?.second?.filter { it.isDigit() }?.takeLast(9)
        val out = mutableListOf<String>()
        ctx.contentResolver.query(
            Telephony.Sms.CONTENT_URI,
            arrayOf(Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE, Telephony.Sms.TYPE),
            null, null, "date DESC LIMIT 300"
        )?.use { c ->
            while (c.moveToNext() && out.size < count) {
                val addr = c.getString(0) ?: continue
                if (tail != null && !addr.filter { it.isDigit() }.endsWith(tail)) continue
                val body = (c.getString(1) ?: "").take(300)
                val whenS = fmt.format(Date(c.getLong(2)))
                val sent = c.getInt(3) == Telephony.Sms.MESSAGE_TYPE_SENT
                val name = nameFor(ctx, addr)
                out += if (sent) "[$whenS] Me to $name: $body" else "[$whenS] $name: $body"
            }
        }
        return if (out.isEmpty()) "No texts found." else out.joinToString("\n")
    }

    private fun sendSms(ctx: Context, to: String, text: String, confirmed: Boolean): String {
        if (!confirmed) return "NOT SENT. Read the recipient and exact message back to the user and ask if you should send it."
        if (text.isBlank()) return "Empty message, nothing sent."
        need(ctx, Manifest.permission.SEND_SMS, "Send SMS")
        val (name, number) = resolve(ctx, to)
        val sm = ctx.getSystemService(SmsManager::class.java)
        val parts = sm.divideMessage(text)
        if (parts.size > 1) sm.sendMultipartTextMessage(number, null, parts, null, null)
        else sm.sendTextMessage(number, null, text, null, null)
        return "Text sent to $name."
    }

    // ---------- other chat apps ----------
    private fun notifs(): String {
        if (!MessageListener.connected)
            return "Notification access is off. Tell the user to enable it from the Capri app."
        val items = MessageListener.snapshot()
        return if (items.isEmpty()) "No recent chat notifications." else items.joinToString("\n")
    }

    private fun replyMsg(ctx: Context, sender: String, text: String, confirmed: Boolean): String {
        if (!confirmed) return "NOT SENT. Read the recipient and exact reply back to the user and ask if you should send it."
        if (text.isBlank()) return "Empty reply, nothing sent."
        if (!MessageListener.connected) return "Notification access is off. Tell the user to enable it from the Capri app."
        return try { MessageListener.reply(ctx, sender, text) } catch (e: Exception) { "Couldn't send the reply: ${e.message}" }
    }

    @Suppress("DEPRECATION")
    private fun openApp(ctx: Context, q: String): String {
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        )
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().equals(q, true) }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().contains(q, true) }
            ?: return "No app named '$q'."
        val i = pm.getLaunchIntentForPackage(hit.activityInfo.packageName)
            ?: return "That app can't be launched."
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Opened ${hit.loadLabel(pm)}."
    }
}
