package com.example.companion

import android.app.Notification
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private class ReplyTarget(val app: String, val action: Notification.Action, val input: RemoteInput)

/** Collects chat notifications (WhatsApp, Instagram, SMS...) so Capri can read and reply to them. */
class MessageListener : NotificationListenerService() {

    override fun onListenerConnected() { connected = true }
    override fun onListenerDisconnected() { connected = false }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return
        val cat = n.category
        if (cat != Notification.CATEGORY_MESSAGE && cat != Notification.CATEGORY_EMAIL &&
            cat != Notification.CATEGORY_SOCIAL) return

        val title = n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = n.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: return
        val app = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (e: Exception) { sbn.packageName }

        val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(sbn.postTime))
        synchronized(buf) {
            buf.addLast("[$time] $app - $title: $text")
            while (buf.size > 30) buf.removeFirst()
        }

        // remember how to reply to this chat
        n.actions?.forEach { a ->
            val ri = a.remoteInputs?.firstOrNull { it.allowFreeFormInput }
            if (ri != null) synchronized(replies) {
                replies.remove(title.lowercase())
                replies[title.lowercase()] = ReplyTarget(app, a, ri)
                while (replies.size > 20) replies.remove(replies.keys.first())
            }
        }
        onNew?.invoke(app, title, text)
    }

    companion object {
        @Volatile var connected = false
        @Volatile var onNew: ((String, String, String) -> Unit)? = null
        private val buf = ArrayDeque<String>()
        private val replies = LinkedHashMap<String, ReplyTarget>()

        fun snapshot(): List<String> = synchronized(buf) { buf.toList() }

        /** Sends a reply through the original chat app's own notification reply button. */
        fun reply(ctx: Context, who: String, text: String): String {
            val t = synchronized(replies) {
                replies.entries.lastOrNull { it.key.contains(who.lowercase()) }?.value
            } ?: return "No recent chat notification from '$who' to reply to."
            val intent = Intent()
            val bundle = Bundle().apply { putCharSequence(t.input.resultKey, text) }
            RemoteInput.addResultsToIntent(arrayOf(t.input), intent, bundle)
            t.action.actionIntent.send(ctx, 0, intent)
            return "Replied to $who on ${t.app}."
        }
    }
}
