package com.example.companion

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("capri", Context.MODE_PRIVATE)

    fun str(c: Context, k: String, d: String = ""): String = sp(c).getString(k, d) ?: d
    fun setStr(c: Context, k: String, v: String) = sp(c).edit().putString(k, v).apply()

    fun apiKey(c: Context): String = str(c, "key")
    fun setApiKey(c: Context, v: String) = setStr(c, "key", v.trim())

    fun voice(c: Context): String = str(c, "voice")
    fun setVoice(c: Context, v: String) = setStr(c, "voice", v)

    fun pitch(c: Context): Float = sp(c).getFloat("pitch", 1.1f)
    fun setPitch(c: Context, v: Float) = sp(c).edit().putFloat("pitch", v).apply()
    fun rate(c: Context): Float = sp(c).getFloat("rate", 1.05f)
    fun setRate(c: Context, v: Float) = sp(c).edit().putFloat("rate", v).apply()

    fun flag(c: Context, k: String): Boolean = sp(c).getBoolean(k, false)
    fun setFlag(c: Context, k: String, v: Boolean) = sp(c).edit().putBoolean(k, v).apply()

    fun applyVoice(c: Context, tts: TextToSpeech) {
        tts.language = Locale.getDefault()
        val v = voice(c)
        if (v.isNotEmpty()) tts.voices?.firstOrNull { it.name == v }?.let { tts.voice = it }
        tts.setPitch(pitch(c))
        tts.setSpeechRate(rate(c))
    }
}
