package com.example.companion

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.graphics.Bitmap
import android.graphics.Outline
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.ServiceCompat
import java.io.ByteArrayOutputStream
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.random.Random

class CompanionService : Service(), TextToSpeech.OnInitListener {

    private val main = Handler(Looper.getMainLooper())
    private val net = Executors.newSingleThreadExecutor()
    private val frameThread = HandlerThread("frames").also { it.start() }
    private lateinit var wm: WindowManager

    private var bubble: FrameLayout? = null
    private var avatar: FrameLayout? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var floatAnim: ObjectAnimator? = null
    private var pulseAnim: ValueAnimator? = null
    private var screenW = 0
    private var screenH = 0
    private var touching = false
    private var panel: TextView? = null
    private var inputBar: LinearLayout? = null

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var lastConv = 0L

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var relistenAfter = false

    private var busy = false
    private var listening = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || projection != null) return START_NOT_STICKY
        startAsForeground()

        val code = intent.getIntExtra("code", Activity.RESULT_CANCELED)
        val data = readData(intent)
        if (code != Activity.RESULT_OK || data == null) {
            stopSelf(); return START_NOT_STICKY
        }

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startCapture(code, data)
        buildOverlay()
        tts = TextToSpeech(this, this)
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(listener)
        }
        MessageListener.onNew = { app, title, text ->
            main.post {
                if (Prefs.flag(this, "announce") && !busy && !listening) {
                    val s = "$title on $app says: $text"
                    show(s); speak(s, false)
                }
            }
        }
        running = true
        main.postDelayed(watchTick, 30000)
        main.postDelayed(roamTick, 25000)
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun readData(i: Intent): Intent? =
        if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra("data", Intent::class.java)
        else i.getParcelableExtra("data")

    private fun startAsForeground() {
        val ch = "capri"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "Capri", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch)
            .setContentTitle("Capri is on")
            .setContentText("Tap the bubble to talk, hold it to type")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        ServiceCompat.startForeground(
            this, 1, n,
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        )
    }

    // ---------- Screen capture ----------
    private fun startCapture(code: Int, data: Intent) {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val p = mpm.getMediaProjection(code, data)
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, main)
        projection = p

        val b = wm.maximumWindowMetrics.bounds
        val w = b.width(); val h = b.height()
        screenW = w; screenH = h
        val dpi = resources.configuration.densityDpi
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        r.setOnImageAvailableListener({ rd ->
            val img = rd.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val now = SystemClock.uptimeMillis()
                if (now - lastConv >= 500) {
                    lastConv = now
                    lastJpeg = toJpeg(img)
                }
            } finally { img.close() }
        }, Handler(frameThread.looper))
        reader = r
        display = p.createVirtualDisplay(
            "capri", w, h, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
        )
    }

    private fun toJpeg(img: Image): ByteArray {
        val plane = img.planes[0]
        val w = img.width; val h = img.height
        val rowPad = plane.rowStride - plane.pixelStride * w
        val full = Bitmap.createBitmap(w + rowPad / plane.pixelStride, h, Bitmap.Config.ARGB_8888)
        full.copyPixelsFromBuffer(plane.buffer)
        val cropped = Bitmap.createBitmap(full, 0, 0, w, h)
        val small = Bitmap.createScaledBitmap(cropped, w / 2, h / 2, true)
        val out = ByteArrayOutputStream()
        small.compress(Bitmap.CompressFormat.JPEG, 70, out)
        full.recycle(); cropped.recycle(); small.recycle()
        return out.toByteArray()
    }

    // ---------- Overlay UI ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildOverlay() {
        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

        val pLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT,
            type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM; y = dp(90); x = 0 }
        panel = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 15f; maxLines = 8
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = GradientDrawable().apply {
                setColor(Color.argb(210, 20, 20, 30)); cornerRadius = dp(16).toFloat()
            }
            visibility = View.GONE
            setOnClickListener { visibility = View.GONE; tts?.stop() }
        }
        wm.addView(panel, pLp)

        val lp = WindowManager.LayoutParams(
            dp(92), dp(92), type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(4); y = dp(300) }
        bubbleLp = lp
        val img = ImageView(this).apply {
            setImageResource(R.drawable.capri)
            scaleType = ImageView.ScaleType.CENTER_CROP
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) { o.setOval(0, 0, v.width, v.height) }
            }
        }
        avatar = FrameLayout(this).apply {
            setPadding(dp(4), dp(4), dp(4), dp(4))
            addView(img, FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        }
        bubble = FrameLayout(this).apply {
            addView(avatar, FrameLayout.LayoutParams(dp(76), dp(76), Gravity.CENTER))
            setOnTouchListener(dragAndTap(lp))
        }
        setBubble(IDLE)
        wm.addView(bubble, lp)
        startFloat()
    }

    // tap = talk, hold = type, drag = move
    private fun dragAndTap(lp: WindowManager.LayoutParams) = object : View.OnTouchListener {
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
        var moved = false; var longDone = false
        val longPress = Runnable { if (!moved) { longDone = true; showInput() } }

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY
                    moved = false; longDone = false; touching = true
                    main.postDelayed(longPress, 600)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) { moved = true; main.removeCallbacks(longPress) }
                    lp.x = sx + dx; lp.y = sy + dy
                    wm.updateViewLayout(v, lp)
                }
                MotionEvent.ACTION_UP -> {
                    touching = false
                    main.removeCallbacks(longPress)
                    if (!moved && !longDone) onBubbleTap()
                }
            }
            return true
        }
    }

    private fun setBubble(color: Int) {
        avatar?.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }
    }

    // gentle idle bobbing, so she feels alive
    private fun startFloat() {
        val a = avatar ?: return
        floatAnim = ObjectAnimator.ofFloat(a, View.TRANSLATION_Y, -dp(5).toFloat(), dp(5).toFloat()).apply {
            duration = 1600; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE; start()
        }
    }

    // pulse while she is talking
    private fun startPulse() {
        val a = avatar ?: return
        pulseAnim?.cancel()
        pulseAnim = ValueAnimator.ofFloat(1f, 1.14f).apply {
            duration = 320; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE
            addUpdateListener { v -> val f = v.animatedValue as Float; a.scaleX = f; a.scaleY = f }
            start()
        }
    }

    private fun stopPulse() {
        pulseAnim?.cancel(); pulseAnim = null
        avatar?.apply { scaleX = 1f; scaleY = 1f }
    }

    // optional: she drifts to a new spot on the screen every so often
    private val roamTick = object : Runnable {
        override fun run() {
            val lp = bubbleLp; val v = bubble
            if (Prefs.flag(this@CompanionService, "roam") && lp != null && v != null &&
                !touching && !listening && !busy && inputBar == null && screenW > 0) {
                val tx = if (Random.nextBoolean()) dp(4) else screenW - dp(96)
                val ty = Random.nextInt(dp(200), (screenH - dp(400)).coerceAtLeast(dp(201)))
                val sx = lp.x; val sy = lp.y
                ValueAnimator.ofFloat(0f, 1f).apply {
                    duration = 1800
                    addUpdateListener { an ->
                        val f = an.animatedValue as Float
                        lp.x = (sx + (tx - sx) * f).toInt()
                        lp.y = (sy + (ty - sy) * f).toInt()
                        runCatching { wm.updateViewLayout(v, lp) }
                    }
                    start()
                }
            }
            main.postDelayed(this, 25000)
        }
    }

    private fun show(text: String) {
        panel?.apply { this.text = text; visibility = View.VISIBLE }
    }

    // ---------- Typing overlay ----------
    private fun showInput() {
        if (inputBar != null) return
        val et = EditText(this).apply {
            hint = "Message Capri"; setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
            maxLines = 3
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val send = Button(this).apply { text = "Send" }
        val close = Button(this).apply { text = "X" }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(Color.argb(240, 20, 20, 30))
            addView(close); addView(et); addView(send)
        }
        close.setOnClickListener { closeInput() }
        send.setOnClickListener {
            val t = et.text.toString().trim()
            closeInput()
            if (t.isNotEmpty() && !busy) { tts?.stop(); show("You: $t"); ask(t) }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or
                WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE
        }
        wm.addView(bar, lp)
        inputBar = bar
        et.requestFocus()
        main.postDelayed({
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(et, 0)
        }, 250)
    }

    private fun closeInput() {
        inputBar?.let { runCatching { wm.removeView(it) } }
        inputBar = null
    }

    // ---------- Voice ----------
    private fun onBubbleTap() {
        closeInput()
        tts?.stop()
        if (listening) { recognizer?.stopListening(); return }
        startListening()
    }

    private fun startListening() {
        if (busy || listening) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { show("Speech recognition isn't available."); return }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        listening = true
        setBubble(LISTEN)
        recognizer?.startListening(i)
    }

    private val listener = object : RecognitionListener {
        override fun onResults(results: Bundle?) {
            listening = false
            val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (t.isNullOrBlank()) { setBubble(IDLE); return }
            show("You: $t")
            ask(t)
        }
        override fun onError(error: Int) {
            listening = false; setBubble(IDLE)
            show("Didn't catch that. Tap and try again.")
        }
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        ttsReady = true
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) { main.post { startPulse() } }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { main.post { stopPulse() } }
            override fun onStop(utteranceId: String?, interrupted: Boolean) { main.post { stopPulse() } }
            override fun onDone(utteranceId: String?) {
                main.post {
                    stopPulse()
                    if (relistenAfter && Prefs.flag(this@CompanionService, "hands_free")) {
                        relistenAfter = false
                        startListening()
                    }
                }
            }
        })
    }

    private fun speak(t: String, relisten: Boolean) {
        val engine = tts ?: return
        if (!ttsReady) return
        relistenAfter = relisten
        Prefs.applyVoice(this, engine)
        engine.speak(t.replace("*", ""), TextToSpeech.QUEUE_FLUSH, null, "capri")
    }

    // ---------- Brain ----------
    private fun ask(userText: String) {
        busy = true; setBubble(THINK)
        val jpeg = lastJpeg
        val ctx = applicationContext
        net.execute {
            try {
                val reply = Brain.ask(ctx, userText, jpeg)
                main.post { busy = false; setBubble(IDLE); show(reply); speak(reply, true) }
            } catch (e: Exception) {
                main.post { busy = false; setBubble(IDLE); show("Error: ${e.message}") }
            }
        }
    }

    // ---------- Watch-along: she comments on what you watch, by herself ----------
    private var lastAutoHash = 0
    private val watchTick = object : Runnable {
        override fun run() {
            val j = lastJpeg
            if (Prefs.flag(this@CompanionService, "watch") && !busy && !listening &&
                inputBar == null && tts?.isSpeaking != true && j != null) {
                val h = j.contentHashCode()
                if (h != lastAutoHash) { lastAutoHash = h; autoGlance(j) }
            }
            main.postDelayed(this, 30000)
        }
    }

    private fun autoGlance(jpeg: ByteArray) {
        busy = true
        val ctx = applicationContext
        net.execute {
            try {
                val r = Brain.ask(ctx, AUTO_PROMPT, jpeg, true)
                main.post { busy = false; if (r.isNotBlank()) { show(r); speak(r, false) } }
            } catch (e: Exception) {
                main.post { busy = false }
            }
        }
    }

    override fun onDestroy() {
        main.removeCallbacks(watchTick)
        main.removeCallbacks(roamTick)
        floatAnim?.cancel(); pulseAnim?.cancel()
        running = false
        MessageListener.onNew = null
        closeInput()
        runCatching { bubble?.let { wm.removeView(it) } }
        runCatching { panel?.let { wm.removeView(it) } }
        runCatching { display?.release() }
        runCatching { reader?.close() }
        runCatching { projection?.stop() }
        runCatching { recognizer?.destroy() }
        runCatching { tts?.shutdown() }
        net.shutdown(); frameThread.quitSafely()
        super.onDestroy()
    }

    companion object {
        @Volatile var lastJpeg: ByteArray? = null
        @Volatile var running = false
        private const val AUTO_PROMPT =
            "(Automatic glance, the user didn't speak.) Look at the screen. If something is genuinely " +
            "worth a quick one-sentence reaction, say it in character. Otherwise reply with exactly: SKIP"
        private val IDLE = Color.parseColor("#6C5CE7")
        private val LISTEN = Color.parseColor("#E84393")
        private val THINK = Color.parseColor("#FDCB6E")
    }
}
