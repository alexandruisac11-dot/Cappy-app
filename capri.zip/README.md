# Capri v0.3

Voice + text AI companion with an anime-Capri personality. Sees your screen,
reads and sends texts, reads your call log, calls/answers/hangs up, reads and
replies to WhatsApp/Instagram-style chat notifications, opens apps, remembers things.

## Build with no PC
1. github.com (phone browser) > New repository (name it capri, public or private).
2. Add file > Create new file. Name: `.github/workflows/build.yml`
   Paste the workflow text. Commit.
3. Add file > Upload files > pick `capri.zip` (do NOT unzip). Commit.
   (Updating later? Upload a new capri.zip with the same name, it replaces the old one.)
4. Actions tab > wait for the green check (3-5 min).
5. Open the repo > Releases (right side) > latest build > tap `app-debug.apk` to download.
6. Tap the downloaded APK > allow "install unknown apps" > Install.
7. Red X in Actions? Open the run, copy the red error text, send it to Claude.

## First run on the S22
1. Paste your API key (console.anthropic.com), Save key.
2. Allow floating bubble. Allow mic, contacts, texts, calls (tap Allow on every prompt).
3. Allow reading message notifications (turn Capri ON).
4. If Android blocks SMS/Call log/Notification permissions ("restricted setting"):
   Settings > Apps > Capri > three dots (top right) > Allow restricted settings. Then retry the permission button.
5. Pick a voice, set pitch/speed, Test voice. Edit her personality if you like.
6. Start Capri, accept screen sharing, open TikTok.

## Using her
- Tap bubble: talk. Hold bubble: type. Drag: move. Tap reply box: dismiss.
- "Call Mom." / "Answer it." / "Hang up."
- "Read my last texts from Mom." / "Text Mom I'm on my way." (she reads it back and asks first)
- "Who messaged me on WhatsApp?" / "Reply to Alex: ok see you there."
- "Open Instagram." / "What's that guy saying in this video?"
- Watch along (toggle): every ~30s she glances at the screen and reacts only if worth it.
- Hands-free toggle: she listens again after she speaks.

## Notes
- Each message (and each watch-along glance) sends a screenshot to the API = costs credit.
- She always asks before sending texts/replies. Calls go out right away when the contact is clear.
- Memory and chat history are saved on the phone. "Clear chat and memory" wipes them.
- Keep your API key private. It is stored only on your phone, never in the code.
