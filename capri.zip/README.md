# Capri v0.5 (runs on a FREE Google Gemini key)

## Get the free key (phone browser)
1. Go to aistudio.google.com, sign in with Google.
2. Tap "Get API key" > Create API key. Copy it (starts with AIza).
3. In Capri: paste it in box 1, tap Save key. Leave Model empty.
Free tier = rate limited. Chat normally; keep "Watch along" OFF.
Note: on the free tier Google may use what you send to improve its models.

## Build with no PC
1. Replace `capri.zip` in your GitHub repo (Add file > Upload files, same name). Commit.
2. Actions tab > wait for green check > Releases > download app-debug.apk > install.
   If install fails, uninstall old Capri first.

## Voice
Pick a voice in the list, then try "Preset: bright anime girl" and Test voice.
Install "Speech Services by Google" from Play Store for more voices.

## Using her
Tap bubble: talk. Hold bubble: type. Drag: move.
"Call Mom", "read my texts", "open TikTok", "what do you think of this video?"
She asks before sending any text.
